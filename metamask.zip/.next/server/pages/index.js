"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Wallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Wallet */ \"./components/Wallet.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Wallet__WEBPACK_IMPORTED_MODULE_2__]);\n_Wallet__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nconst Layout = ({ title  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Wallet__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Taranjot Singh\\\\Desktop\\\\MetaMask\\\\metamask-wallet\\\\components\\\\Layout.js\",\n            lineNumber: 7,\n            columnNumber: 9\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Taranjot Singh\\\\Desktop\\\\MetaMask\\\\metamask-wallet\\\\components\\\\Layout.js\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQXlCO0FBQ0k7QUFFN0IsTUFBTUUsU0FBUyxDQUFDLEVBQUNDLE1BQUssRUFBQyxHQUFLO0lBQzFCLHFCQUNFLDhEQUFDQztrQkFDRyw0RUFBQ0gsK0NBQU1BOzs7Ozs7Ozs7O0FBR2Y7QUFFQSxpRUFBZUMsTUFBTUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL21ldGFtYXNrLXdhbGxldC8uL2NvbXBvbmVudHMvTGF5b3V0LmpzPzUxNWMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgV2FsbGV0IGZyb20gJy4vV2FsbGV0J1xyXG5cclxuY29uc3QgTGF5b3V0ID0gKHt0aXRsZX0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgICA8V2FsbGV0IC8+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IExheW91dCJdLCJuYW1lcyI6WyJSZWFjdCIsIldhbGxldCIsIkxheW91dCIsInRpdGxlIiwiZGl2Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/Wallet.js":
/*!******************************!*\
  !*** ./components/Wallet.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _web3modal_ethereum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @web3modal/ethereum */ \"@web3modal/ethereum\");\n/* harmony import */ var _web3modal_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @web3modal/react */ \"@web3modal/react\");\n/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! wagmi */ \"wagmi\");\n/* harmony import */ var wagmi_chains__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! wagmi/chains */ \"wagmi/chains\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_web3modal_ethereum__WEBPACK_IMPORTED_MODULE_2__, _web3modal_react__WEBPACK_IMPORTED_MODULE_3__, wagmi__WEBPACK_IMPORTED_MODULE_4__, wagmi_chains__WEBPACK_IMPORTED_MODULE_5__]);\n([_web3modal_ethereum__WEBPACK_IMPORTED_MODULE_2__, _web3modal_react__WEBPACK_IMPORTED_MODULE_3__, wagmi__WEBPACK_IMPORTED_MODULE_4__, wagmi_chains__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\nconst Wallet = ()=>{\n    const chains = [\n        wagmi_chains__WEBPACK_IMPORTED_MODULE_5__.arbitrum,\n        wagmi_chains__WEBPACK_IMPORTED_MODULE_5__.goerli,\n        wagmi_chains__WEBPACK_IMPORTED_MODULE_5__.polygon\n    ];\n    // Wagmi client\n    const { provider  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_4__.configureChains)(chains, [\n        (0,_web3modal_ethereum__WEBPACK_IMPORTED_MODULE_2__.walletConnectProvider)({\n            projectId: \"7457869b0c86badd1a89560d294b4714\"\n        })\n    ]);\n    const wagmiClient = (0,wagmi__WEBPACK_IMPORTED_MODULE_4__.createClient)({\n        autoConnect: true,\n        connectors: (0,_web3modal_ethereum__WEBPACK_IMPORTED_MODULE_2__.modalConnectors)({\n            projectId: \"7457869b0c86badd1a89560d294b4714\",\n            version: \"1\",\n            appName: \"web3Modal\",\n            chains\n        }),\n        provider\n    });\n    // Web3Modal Ethereum Client\n    const ethereumClient = new _web3modal_ethereum__WEBPACK_IMPORTED_MODULE_2__.EthereumClient(wagmiClient, chains);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(wagmi__WEBPACK_IMPORTED_MODULE_4__.WagmiConfig, {\n                client: wagmiClient\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Taranjot Singh\\\\Desktop\\\\MetaMask\\\\metamask-wallet\\\\components\\\\Wallet.js\",\n                lineNumber: 33,\n                columnNumber: 5\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_web3modal_react__WEBPACK_IMPORTED_MODULE_3__.Web3Modal, {\n                projectId: \"7457869b0c86badd1a89560d294b4714\",\n                ethereumClient: ethereumClient\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Taranjot Singh\\\\Desktop\\\\MetaMask\\\\metamask-wallet\\\\components\\\\Wallet.js\",\n                lineNumber: 36,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_web3modal_react__WEBPACK_IMPORTED_MODULE_3__.Web3Button, {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Taranjot Singh\\\\Desktop\\\\MetaMask\\\\metamask-wallet\\\\components\\\\Wallet.js\",\n                lineNumber: 40,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wallet);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1dhbGxldC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQXlCO0FBS007QUFDNEI7QUFDVTtBQUNWO0FBRTNELE1BQU1ZLFNBQVMsSUFBTTtJQUNqQixNQUFNQyxTQUFTO1FBQUNKLGtEQUFRQTtRQUFFQyxnREFBTUE7UUFBRUMsaURBQU9BO0tBQUM7SUFFOUMsZUFBZTtJQUNmLE1BQU0sRUFBRUcsU0FBUSxFQUFFLEdBQUdSLHNEQUFlQSxDQUFDTyxRQUFRO1FBQzNDViwwRUFBcUJBLENBQUM7WUFBRVksV0FBVztRQUFtQztLQUN2RTtJQUNELE1BQU1DLGNBQWNULG1EQUFZQSxDQUFDO1FBQy9CVSxhQUFhLElBQUk7UUFDakJDLFlBQVloQixvRUFBZUEsQ0FBQztZQUMxQmEsV0FBVztZQUNYSSxTQUFTO1lBQ1RDLFNBQVM7WUFDVFA7UUFDRjtRQUNBQztJQUNGO0lBRUEsNEJBQTRCO0lBQzVCLE1BQU1PLGlCQUFpQixJQUFJcEIsK0RBQWNBLENBQUNlLGFBQWFIO0lBQ3JELHFCQUNFOzswQkFDQSw4REFBQ0wsOENBQVdBO2dCQUFDYyxRQUFRTjs7Ozs7OzBCQUduQiw4REFBQ1gsdURBQVNBO2dCQUNSVSxXQUFVO2dCQUNWTSxnQkFBZ0JBOzs7Ozs7MEJBRWxCLDhEQUFDakIsd0RBQVVBOzs7Ozs7O0FBR2pCO0FBRUEsaUVBQWVRLE1BQU1BLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tZXRhbWFzay13YWxsZXQvLi9jb21wb25lbnRzL1dhbGxldC5qcz8zMTFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHtcclxuICAgIEV0aGVyZXVtQ2xpZW50LFxyXG4gICAgbW9kYWxDb25uZWN0b3JzLFxyXG4gICAgd2FsbGV0Q29ubmVjdFByb3ZpZGVyLFxyXG4gIH0gZnJvbSBcIkB3ZWIzbW9kYWwvZXRoZXJldW1cIjtcclxuICBpbXBvcnQgeyBXZWIzQnV0dG9uLCBXZWIzTW9kYWwgfSBmcm9tIFwiQHdlYjNtb2RhbC9yZWFjdFwiO1xyXG4gIGltcG9ydCB7IGNvbmZpZ3VyZUNoYWlucywgY3JlYXRlQ2xpZW50LCBXYWdtaUNvbmZpZyB9IGZyb20gXCJ3YWdtaVwiO1xyXG4gIGltcG9ydCB7IGFyYml0cnVtLCBnb2VybGksIHBvbHlnb24gfSBmcm9tIFwid2FnbWkvY2hhaW5zXCI7XHJcblxyXG5jb25zdCBXYWxsZXQgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBjaGFpbnMgPSBbYXJiaXRydW0sIGdvZXJsaSwgcG9seWdvbl07XHJcblxyXG4vLyBXYWdtaSBjbGllbnRcclxuY29uc3QgeyBwcm92aWRlciB9ID0gY29uZmlndXJlQ2hhaW5zKGNoYWlucywgW1xyXG4gIHdhbGxldENvbm5lY3RQcm92aWRlcih7IHByb2plY3RJZDogXCI3NDU3ODY5YjBjODZiYWRkMWE4OTU2MGQyOTRiNDcxNFwiIH0pLFxyXG5dKTtcclxuY29uc3Qgd2FnbWlDbGllbnQgPSBjcmVhdGVDbGllbnQoe1xyXG4gIGF1dG9Db25uZWN0OiB0cnVlLFxyXG4gIGNvbm5lY3RvcnM6IG1vZGFsQ29ubmVjdG9ycyh7XHJcbiAgICBwcm9qZWN0SWQ6IFwiNzQ1Nzg2OWIwYzg2YmFkZDFhODk1NjBkMjk0YjQ3MTRcIixcclxuICAgIHZlcnNpb246IFwiMVwiLCAvLyBvciBcIjJcIlxyXG4gICAgYXBwTmFtZTogXCJ3ZWIzTW9kYWxcIixcclxuICAgIGNoYWlucyxcclxuICB9KSxcclxuICBwcm92aWRlcixcclxufSk7XHJcblxyXG4vLyBXZWIzTW9kYWwgRXRoZXJldW0gQ2xpZW50XHJcbmNvbnN0IGV0aGVyZXVtQ2xpZW50ID0gbmV3IEV0aGVyZXVtQ2xpZW50KHdhZ21pQ2xpZW50LCBjaGFpbnMpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgPFdhZ21pQ29uZmlnIGNsaWVudD17d2FnbWlDbGllbnR9PlxyXG4gICAgICA8L1dhZ21pQ29uZmlnPlxyXG5cclxuICAgICAgPFdlYjNNb2RhbFxyXG4gICAgICAgIHByb2plY3RJZD1cIjc0NTc4NjliMGM4NmJhZGQxYTg5NTYwZDI5NGI0NzE0XCJcclxuICAgICAgICBldGhlcmV1bUNsaWVudD17ZXRoZXJldW1DbGllbnR9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxXZWIzQnV0dG9uIC8+XHJcbiAgICA8Lz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFdhbGxldCJdLCJuYW1lcyI6WyJSZWFjdCIsIkV0aGVyZXVtQ2xpZW50IiwibW9kYWxDb25uZWN0b3JzIiwid2FsbGV0Q29ubmVjdFByb3ZpZGVyIiwiV2ViM0J1dHRvbiIsIldlYjNNb2RhbCIsImNvbmZpZ3VyZUNoYWlucyIsImNyZWF0ZUNsaWVudCIsIldhZ21pQ29uZmlnIiwiYXJiaXRydW0iLCJnb2VybGkiLCJwb2x5Z29uIiwiV2FsbGV0IiwiY2hhaW5zIiwicHJvdmlkZXIiLCJwcm9qZWN0SWQiLCJ3YWdtaUNsaWVudCIsImF1dG9Db25uZWN0IiwiY29ubmVjdG9ycyIsInZlcnNpb24iLCJhcHBOYW1lIiwiZXRoZXJldW1DbGllbnQiLCJjbGllbnQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Wallet.js\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/Layout */ \"./components/Layout.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout__WEBPACK_IMPORTED_MODULE_1__]);\n_components_Layout__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction Home() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n        title: \"Donate CryptoCurrency\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Taranjot Singh\\\\Desktop\\\\MetaMask\\\\metamask-wallet\\\\pages\\\\index.js\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUdNQTtBQUZrQztBQUl6QixTQUFTRSxPQUFPO0lBQzdCLHFCQUNFLDhEQUFDRCwwREFBTUE7UUFBQ0UsT0FBTTtrQkFDZDs7Ozs7O0FBSUosQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL21ldGFtYXNrLXdhbGxldC8uL3BhZ2VzL2luZGV4LmpzP2JlZTciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW50ZXIgfSBmcm9tICduZXh0L2ZvbnQvZ29vZ2xlJ1xuaW1wb3J0IExheW91dCBmcm9tICdAL2NvbXBvbmVudHMvTGF5b3V0J1xuXG5jb25zdCBpbnRlciA9IEludGVyKHsgc3Vic2V0czogWydsYXRpbiddIH0pXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIHJldHVybiAoXG4gICAgPExheW91dCB0aXRsZT1cIkRvbmF0ZSBDcnlwdG9DdXJyZW5jeVwiPlxuICAgIDw+XG4gICAgPC8+XG4gICAgPC9MYXlvdXQ+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJpbnRlciIsIkxheW91dCIsIkhvbWUiLCJ0aXRsZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "@web3modal/ethereum":
/*!**************************************!*\
  !*** external "@web3modal/ethereum" ***!
  \**************************************/
/***/ ((module) => {

module.exports = import("@web3modal/ethereum");;

/***/ }),

/***/ "@web3modal/react":
/*!***********************************!*\
  !*** external "@web3modal/react" ***!
  \***********************************/
/***/ ((module) => {

module.exports = import("@web3modal/react");;

/***/ }),

/***/ "wagmi":
/*!************************!*\
  !*** external "wagmi" ***!
  \************************/
/***/ ((module) => {

module.exports = import("wagmi");;

/***/ }),

/***/ "wagmi/chains":
/*!*******************************!*\
  !*** external "wagmi/chains" ***!
  \*******************************/
/***/ ((module) => {

module.exports = import("wagmi/chains");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();