import React from 'react'
import Wallet from './Wallet'

const Layout = ({title}) => {
  return (
    <div>
        <Wallet />
    </div>
  )
}

export default Layout